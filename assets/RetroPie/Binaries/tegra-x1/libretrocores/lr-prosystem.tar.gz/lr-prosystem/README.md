prosystem-libretro
==================

Port of ProSystem to libretro.

Place "7800 BIOS (U).rom" (optional) in your RetroArch/libretro "System Directory" folder.
