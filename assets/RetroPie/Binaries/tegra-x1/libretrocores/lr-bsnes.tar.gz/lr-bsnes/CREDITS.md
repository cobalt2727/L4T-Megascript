bsnes was created and is maintained by byuu (Near), but many people have contributed to the project.

This software would not be where it is today without the help and support of the following individuals:

  - Andreas Naive
  - Ange Albertini
  - anomie
  - AWJ
  - Bisqwit
  - blargg
  - Łukasz Krawczyk
  - Danish
  - DerKoun
  - DMV27
  - Dr. Decapitator
  - endrift
  - Fatbag
  - FitzRoy
  - gekkio
  - GIGO
  - Hendricks266
  - hex_usr
  - ikari_01
  - jchadwick
  - Jonas Quinn
  - kode54
  - krom
  - Lioncash
  - Lord Nightmare
  - lowkey
  - Matthew Callis
  - Max833
  - MerryMage
  - mightymo
  - Nach
  - ncbncb
  - neviksti
  - OV2
  - Overload
  - p4plus2
  - quequotion
  - RedDwarf
  - Richard Bannister
  - Ryphecha
  - segher
  - Sintendo
  - SuperMikeMan
  - Talarubi
  - tetsuo55
  - TmEE
  - TRAC
  - wareya
  - zones

If your contributions have been missed here, please reach out [here](https://byuu.org/contact) to have this corrected, thank you!
