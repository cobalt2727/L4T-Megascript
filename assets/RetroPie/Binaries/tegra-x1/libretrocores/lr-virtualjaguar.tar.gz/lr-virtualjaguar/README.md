virtualjaguar-libretro
======================

Port of Virtual Jaguar to Libretro

Upstream: `git clone http://shamusworld.gotdns.org/git/virtualjaguar`

Unofficial GitHub mirror: https://github.com/mirror/virtualjaguar

Needs battery saves
