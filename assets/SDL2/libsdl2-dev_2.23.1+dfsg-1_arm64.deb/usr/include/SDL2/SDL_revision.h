#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@59fb7acbf7af9d64a2d5432bb6677585a0ddd50a"
#define SDL_REVISION_NUMBER 0
